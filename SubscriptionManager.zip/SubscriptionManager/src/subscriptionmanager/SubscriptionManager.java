
package subscriptionmanager;


import java.io.File;
import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;



public class SubscriptionManager {

    // this is the main class, this is where we will write all our codes
    public static void main(String[] args) throws FileNotFoundException {
       
        Scanner input = new Scanner(System.in);
         int inputNumber =0 ;
        while(inputNumber != 5 ){
       //here we are asking for input of the following data;
        System.out.println("\n\nPress the following number for following actions:\n"
                + "1. Enter a new Subscription.\n"
                + "2. Display Summary of Subscriptions.\n"
                + "3. Display Summary of subscription for selected months.\n"
                + "4. Find and display subscriptions.\n"
                + "5. Exit");
                inputNumber = input.nextInt();
        
            //if 1 is in input this line of code will run;
            if (inputNumber ==1){
                //here we are asking for their name and stuff which we also have in  subscription.java class,
                //we are inheritiong the value using getter and setter method from there
                System.out.println("Enter First Name: ");
                String firstName = input.next();
                System.out.println("Enter Last Name: ");
                String lastName = input.next();
                System.out.println("Enter Package Type('gaming' or 'anime' or 'movies'): ");
                String packageType = input.next();
                System.out.println("Enter Duration of Contract(1,3,6 or 12): ");
                int duration = input.nextInt();
                System.out.println("Do You want to pay full for 10% discount(One -off):\n"
                        + "If you want one off please type 'true' and enter but if you want to pay monthly please enter'false' and enter ");
                boolean term = input.nextBoolean();
                double cost = 0;
                String termType;
                //if 'gaming' package is choosen then these calculation wwill take place which will determine the cost using package, duration of contract and term
                if(packageType.equals("gaming")){
                    if (duration == 1){
                        cost = 1600;
                    }
                    else if (duration == 3 & term == true){
                        cost = 4050;
                    }
                    else if (duration == 3 & term == false) {
                        cost = 1500;
                    }
                    else if (duration == 6 & term == false) {
                        cost = 1400;
                    }
                    else if (duration == 6 & term == true) {
                        cost = 7020;
                    }
                    else if (duration == 12 & term == false) {
                        cost = 1300;
                    }
                    else if (duration == 12 & term == true ) {
                        cost = 14040;
                    }
                    else if (duration != 1 || duration != 3 || duration != 6 || duration != 12){
                        System.out.println("Please enter the duration as 1 or 3 or 6 or 12 only ");
                    }
                    else
                        System.out.println("Please try  again");
                   
                }
                //if 'anime' package is choosen then these calculation wwill take place which will determine the cost using package, duration of contract and term
                else if(packageType.equals("anime")){
                    if (duration == 1){
                        cost = 1800;
                    }
                    else if (duration == 3 & term == true){
                        cost = 4590;
                    }
                    else if (duration == 3 & term == false) {
                        cost = 1700;
                    }
                    else if (duration == 6 & term == false) {
                        cost = 1600;
                    }
                    else if (duration == 6 & term == true) {
                        cost = 7020;
                    }
                    else if (duration == 12 & term == false) {
                        cost = 1500;
                    }
                    else if (duration == 12 & term == true ) {
                        cost = 1620;
                    }
                    else if (duration != 1 || duration != 3 || duration != 6 || duration != 12){
                        System.out.println("Please enter the duration as 1 or 3 or 6 or 12 only ");
                    }
                    else
                        System.out.println("Please try  again");
                    //if 'movies' package is choosen then these calculation wwill take place which will determine the cost using package, duration of contract and term
                    }
                    else if(packageType.equals("movies")){
                    if (duration == 1){
                        cost = 1999;
                    }
                    else if (duration == 3 & term == true){
                        cost = 51237;
                    }
                    else if (duration == 3 & term == false) {
                        cost = 1899;
                    }
                    else if (duration == 6 & term == false) {
                        cost = 1799;
                    }
                    else if (duration == 6 & term == true) {
                        cost = 97146;
                    }
                    else if (duration == 12 & term == false) {
                        cost = 1699;
                    }
                    else if (duration == 12 & term == true ) {
                        cost = 183492;
                    }
                    else if (duration != 1 || duration != 3 || duration != 6 || duration != 12){
                        System.out.println("Please enter the duration as 1 or 3 or 6 or 12 only ");
                    }
                    else
                        System.out.println("Please try  again");
                }
                
                //here we are determining what to print on scrren based on boolean value
                    if (term == true){
                        termType = "one-off";
                    }
                    else
                        termType = "monthly";
                //we are getting inheritance from subscription.java class
                 Subscription S1;
            S1 = new Subscription(firstName, lastName, packageType,duration, term, cost, termType);
                 System.out.println(S1);
                
             
             //here we are going to write data given during input to subscriptions.txt
             Scanner in = new Scanner(System.in);
             File subFile = new File("subscriptions.txt");
             
             try{
                 FileWriter fw = new FileWriter(subFile, true);
                 packageType = packageType.toUpperCase();
                 termType = termType.toUpperCase();
                 fw.write(getDate() +","+ packageType.substring(0, 1) +","+ duration +","+ termType.substring(0, 1)+","+cost+","+ firstName.substring(0, 1)+" "+ lastName + "\n");
                 System.out.println("Written to file!");
                 fw.flush();
             }
             catch (IOException ex) {
                 System.out.println("Problem writing to file");
              
             }
        }
            // this program gets started if input number = 2
            else if (inputNumber == 2){
                //we are asking for input to choose txt file
                System.out.println("Please enter the description you would like to see \n"
                    + "for 'current' file enter current all small letter\n"
                    + "for 'subs' file enter subscription all small letter");
                String descInput =input.next();
                if (descInput.equals("current")){
            File file = new File("current.txt");
            Scanner fileInput;
                    fileInput = new Scanner(file);
                    //these are the variables we will use in this program
            int totalSubscription =0;
            int totalFee = 0;
            Double prices = 0.00;
            Double gamingP = 0.00;
            Double animeP = 0.00;
            Double moviesP = 0.00;
            int jan = 0;
            int feb = 0;
            int mar = 0;
            int apr = 0;
            int may = 0;
            int jun = 0;
            int jul = 0;
            int aug = 0;
            int sep = 0;
            int oct = 0;
            int nov = 0;
            int dec = 0;
            int totalMonths = 0;
            
            
            
         
            
           
             while(fileInput.hasNextLine()){
                String line = fileInput.nextLine();
                totalSubscription++;
                String[] strLines = new String[6];
                //here we are splitting line of txt file using ,
                strLines = line.split(",");
                totalFee ++;
                prices += Double.parseDouble(strLines[4]);
                totalMonths += Integer.parseInt(strLines[2]);
                //here if second line contains 'G' then this program goes into effect
               if(strLines[1].contains("G")){
                    gamingP++;
                }
               //here if second line contains 'A' then this program goes into effect
                else if(strLines[1].contains("A")){
                    animeP++;
                }
                //here if second line contains 'M' then this program goes into effect
                else if(strLines[1].contains("M")){
                    moviesP++;
                }
                else
                     System.out.println("This is not a type of package");
               //these codes are for ccalculating number of subscription each months
                if (strLines[0].contains("Jan")){
                    jan++;
                }
                else if (strLines[0].contains("Feb")){
                    feb++;
                }
                else if (strLines[0].contains("Mar")){
                    mar++;
                }
                else if (strLines[0].contains("Apr")){
                    apr++;
                }
                else if (strLines[0].contains("May")){
                    may++;
                }
                else if (strLines[0].contains("Jun")){
                    jun++;
                }
                else if (strLines[0].contains("Jul")){
                    jul++;
                }
                else if (strLines[0].contains("Aug")){
                    aug++;
                }
                else if (strLines[0].contains("Sep")){
                    sep++;
                }
                else if (strLines[0].contains("Oct")){
                    oct++;
                }
                else if (strLines[0].contains("Nov")){
                    nov++;
                }
                else if (strLines[0].contains("Dec")){
                    dec++;
                }
                else
                     System.out.println("No such Month");
             
            }
             //here we are doing some maths and printing the value we get from above
              fileInput.close();
              Double gamP = gamingP*100/totalSubscription;
              Double animP = animeP*100/totalSubscription;
              Double moviP = moviesP*100/totalSubscription;
              Double averageFee = prices/100/totalMonths;
            System.out.println("Total number of subscriptions: " + totalSubscription);
            System.out.println("Average monthly subscriptions:" + totalSubscription/12);
            System.out.println("Average monthly subscription fee: " + Math.round(averageFee*100.0)/100.0);
            System.out.println("\n");
            System.out.println("Percentage of Subscriptions: ");
            System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
            System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
            System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
            System.out.println("Jan\tFeb\tMar\tApr\tMay\tJun\tJul\tAug\tSep\tOct\tNov\tDec");
            System.out.println(jan + "\t" + feb + "\t" + mar + "\t" + apr + "\t" + may + "\t" + jun + "\t" + jul + "\t" + aug + "\t" + sep + "\t" + oct + "\t" + nov + "\t" + dec);
            }
            else if (descInput.equals("subs")){
            File file = new File("subscriptions.txt");
            Scanner fileInput = new Scanner(file);
            //these are the variables we will use in this program
            int totalSubscription =0;
            int totalFee = 0;
            Double prices = 0.00;
            Double gamingP = 0.00;
            Double animeP = 0.00;
            Double moviesP = 0.00;
            int jan = 0;
            int feb = 0;
            int mar = 0;
            int apr = 0;
            int may = 0;
            int jun = 0;
            int jul = 0;
            int aug = 0;
            int sep = 0;
            int oct = 0;
            int nov = 0;
            int dec = 0;
            int totalMonths = 0;
            
            
            
         
            
           
             while(fileInput.hasNextLine()){
                String line = fileInput.nextLine();
                totalSubscription++;
                String[] strLines = new String[6];
                //here we are splitting line of txt file using ,
                strLines = line.split(",");
                totalFee ++;
                prices += Double.parseDouble(strLines[4]);
                totalMonths += Integer.parseInt(strLines[2]);
                //here if second line contains 'G' then this program goes into effect
               if(strLines[1].contains("G")){
                    gamingP++;
                }
               //here if second line contains 'A' then this program goes into effect
                else if(strLines[1].contains("A")){
                    animeP++;
                }
                //here if second line contains 'M' then this program goes into effect
                else if(strLines[1].contains("M")){
                    moviesP++;
                }
                else
                     System.out.println("This is not a type of package");
               //these codes are for ccalculating number of subscription each months
                if (strLines[0].contains("Jan")){
                    jan++;
                }
                else if (strLines[0].contains("Feb")){
                    feb++;
                }
                else if (strLines[0].contains("Mar")){
                    mar++;
                }
                else if (strLines[0].contains("Apr")){
                    apr++;
                }
                else if (strLines[0].contains("May")){
                    may++;
                }
                else if (strLines[0].contains("Jun")){
                    jun++;
                }
                else if (strLines[0].contains("Jul")){
                    jul++;
                }
                else if (strLines[0].contains("Aug")){
                    aug++;
                }
                else if (strLines[0].contains("Sep")){
                    sep++;
                }
                else if (strLines[0].contains("Oct")){
                    oct++;
                }
                else if (strLines[0].contains("Nov")){
                    nov++;
                }
                else if (strLines[0].contains("Dec")){
                    dec++;
                }
                else
                     System.out.println("No such Month");
             
            }
             //here we are doing some maths and printing the value we get from above
              fileInput.close();
              Double gamP = gamingP*100/totalSubscription;
              Double animP = animeP*100/totalSubscription;
              Double moviP = moviesP*100/totalSubscription;
              Double averageFee = prices/100/totalMonths;
            System.out.println("Total number of subscriptions: " + totalSubscription);
            System.out.println("Average monthly subscriptions:" + totalSubscription/12);
            System.out.println("Average monthly subscription fee: " + Math.round(averageFee*100.0)/100.0);
            System.out.println("\n");
            System.out.println("Percentage of Subscriptions: ");
            System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
            System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
            System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
            System.out.println("Jan\tFeb\tMar\tApr\tMay\tJun\tJul\tAug\tSep\tOct\tNov\tDec");
            System.out.println(jan + "\t" + feb + "\t" + mar + "\t" + apr + "\t" + may + "\t" + jun + "\t" + jul + "\t" + aug + "\t" + sep + "\t" + oct + "\t" + nov + "\t" + dec);
            }
                
            }
        //this line of code will run if input number is choosen as 3    
        else if (inputNumber == 3) {
            //her we are asking to choose between current file and dubscription file
            System.out.println("Please enter the description you would like to see \n"
                    + "for 'current' file enter current all small letter\n"
                    + "for 'subs' file enter subscription all small letter");
            String fileInput = input.next();
            if (fileInput.equals("current")){
                 File file = new File("current.txt");
                try (Scanner currentInput = new Scanner(file)) {
                    //here we are asking for inputting month
                    System.out.println("Please enter the months you would like to see description of in small letter( For example:jan for january): ");
                    String monthInput = input.next();
                    //this line of code will run if january is choosen
                    if (monthInput.equals("jan")) {
                        //these are the variables we will use
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();
                            //we are looking if the line contains Jan so that we can do operation
                            if (line.contains("Jan")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                            //here we are calculating things to show the value for jan
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for January: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);


                    }
                    //this is the same process ans january
                    else if (monthInput.equals("feb")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Feb")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for February: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);


                    }
                    //this is the same process as february
                    else if (monthInput.equals("mar")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Mar")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for March: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);


                    }
                    //this is the same process an january
                    else if (monthInput.equals("apr")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Apr")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for April: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);


                    }
                    //this is the same process an january
                    else if (monthInput.equals("may")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("May")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for May: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("jun")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Jun")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for June: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("jul")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Jul")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for July: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("aug")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Aug")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for August: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("sep")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Sep")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for September: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("oct")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Oct")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for October: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("nov")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Nov")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for November: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    }
                    //this is the same process an january
                    else if (monthInput.equals("dec")) {
                        int counter = 0;
                        int monthCounter = 0;
                        Double monthPrice = 0.0;
                        Double gamingP = 0.00;
                        Double animeP = 0.00;
                        Double moviesP = 0.00;
                        int totalMonth = 0;
                        while (currentInput.hasNextLine()) {
                            String line = currentInput.nextLine();

                            if (line.contains("Dec")) {
                                String[] strLines = new String[6];
                                strLines = line.split(",");
                                monthCounter++;
                                totalMonth += Integer.parseInt(strLines[2]);
                                monthPrice += Double.parseDouble(strLines[4]);
                                switch (strLines[1]) {
                                    case "G":
                                        gamingP++;
                                        break;
                                    case "A":
                                        animeP++;
                                        break;
                                    case "M":
                                        moviesP++;
                                        break;
                                    default:
                                        System.out.println("Not a package Type");
                                        break;
                                }

                            }
                            counter++;
                        }
                        currentInput.close();
                        Double gamP = gamingP * 100 / monthCounter;
                        Double animP = animeP * 100 / monthCounter;
                        Double moviP = moviesP * 100 / monthCounter;
                        Double averageSubscription = monthPrice / 100 / totalMonth;
                        System.out.println("Total number of subscription for December: " + monthCounter);
                        System.out.println("Average subscription fee: " + Math.round(averageSubscription * 100.0) / 100.0);
                        System.out.println(" ");
                        System.out.println("Percentage of subscriptions: ");
                        System.out.println("Gaming: " + Math.round(gamP * 100.0) / 100.0);
                        System.out.println("Anime: " + Math.round(animP * 100.0) / 100.0);
                        System.out.println("Movies: " + Math.round(moviP * 100.0) / 100.0);
                    } else
                        System.out.println("No such month");
                }


            }
            //this is the same process as for current file
            else if (fileInput.equals("subs")){
                 File file = new File("subscriptions.txt");
                 Scanner currentInput = new Scanner(file);
                System.out.println("Please enter the months you would like to see description of in small letter( For example:jan for january): ");
                String monthInput = input.next();
                if (monthInput.equals("jan")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Jan")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for January: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
                    
                    
                  
                    
                    
                }
                else if (monthInput.equals("feb")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Feb")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for February: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
                    
                    
                  
                    
                    
                }
                else if (monthInput.equals("mar")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Mar")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for March: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
                    
                    
                  
                    
                    
                }
                else if (monthInput.equals("apr")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Apr")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for April: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);
                    
                    
                  
                    
                    
                }
                else if (monthInput.equals("may")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("May")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for May: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("jun")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Jun")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for June: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("jul")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Jul")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for July: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("aug")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Aug")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for August: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("sep")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Sep")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for September: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("oct")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Oct")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for October: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else if (monthInput.equals("nov")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Nov")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for November: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }else if (monthInput.equals("dec")) {
                    int counter = 0;
                    int monthCounter = 0;
                    Double monthPrice = 0.0;
                    Double gamingP = 0.00;
                    Double animeP = 0.00;
                    Double moviesP = 0.00;
                    int totalMonth = 0;
                    while(currentInput.hasNextLine()){
                         String line = currentInput.nextLine();
                        
                        if (line.contains("Dec")) {
                            String[] strLines = new String[6];
                            strLines = line.split(",");
                            monthCounter++;
                            totalMonth += Integer.parseInt(strLines[2]);
                            monthPrice += Double.parseDouble(strLines[4]);
                             switch (strLines[1]) {
                                 case "G":
                                     gamingP++;
                                     break;
                                 case "A":
                                     animeP++;
                                     break;
                                 case "M":
                                     moviesP++;
                                     break;
                                 default:
                                     System.out.println("Not a package Type");
                                     break;
                             }
                          
                        }
                        counter++;                        
                    }
                    currentInput.close();
                    Double gamP = gamingP*100/monthCounter;
                    Double animP = animeP*100/monthCounter;
                    Double moviP = moviesP*100/monthCounter;
                    Double averageSubscription = monthPrice/100/totalMonth;
                    System.out.println("Total number of subscription for December: " + monthCounter);
                    System.out.println("Average subscription fee: " + Math.round(averageSubscription*100.0)/100.0);
                    System.out.println(" ");
                    System.out.println("Percentage of subscriptions: ");
                    System.out.println("Gaming: " + Math.round(gamP*100.0)/100.0);
                    System.out.println("Anime: " + Math.round(animP*100.0)/100.0);
                    System.out.println("Movies: " + Math.round(moviP*100.0)/100.0);     
                }
                else
                    System.out.println("No such month");
                
                
            }    
        }
        //this line of code will run if input number is 4
        else if (inputNumber == 4){
            //first e ask input for current file
            System.out.println("Please enter the file you would like to search from \n"
                    + "for 'current' file enter current all small letter\n"
                    + "for 'subs' file enter subscription all small letter");
            String inputType = input.next();
            //this code will run if input is current
            if(inputType.equals("current")){
                 File file = new File("current.txt");
            Scanner currentInput = new Scanner(file);
            //these are the variables
            int counter = 0;
            int nameCounter = 0;
            String pkgType = "";
            String trmType = "";
            Double totalPrice = 0.0;
            //here we ask the input for name
            System.out.println("Please enter name or letters in name: ");
                String wordsInName = input.next();
            while(currentInput.hasNextLine()){
                String line = currentInput.nextLine();
                String[] strLines = new String[6];
                strLines = line.split(",");
                counter++;
                
                //if the word matches with name thin this process happens
                if (strLines[5].contains(wordsInName)){
                nameCounter++;
                String[] strLine = new String[6];
                strLine =line.split(",");
                totalPrice = Double.parseDouble(strLine[4]);
                if (strLine[1].equals("G")){
                    pkgType = "Gaming";
                }
                else if (strLine[1].equals("A")){
                    pkgType = "Anime";
                }
                if (strLine[1].equals("M")){
                    pkgType = "Movies";
                }
                if (strLine[3].equals("O")){
                    trmType = "One-off";
                }
                else if (strLine[3].equals("M")){
                    trmType = "monthly";
                }
                //these will be prnted
                System.out.println("+---------------------------------------+");
                System.out.println("| Customer Name: " + strLine[5]);
                System.out.println("| Subscription Date: " + strLine[0]);
                System.out.println("| Package Type: " + pkgType);
                System.out.println("| Term: " + trmType + "\n");
                System.out.println("| Cost: " + totalPrice/100);
                System.out.println("+----------------------------------------+");
                   
                }
            }
            //this code is same as current file
            }
            else if(inputType.equals("subs")){
                 File file = new File("subscriptions.txt");
            Scanner currentInput = new Scanner(file);
            int counter = 0;
            int nameCounter = 0;
            String pkgType = "";
            String trmType = "";
            Double totalPrice = 0.0;
            System.out.println("Please enter name or letters in name: ");
                String wordsInName = input.next();
                while(currentInput.hasNextLine()){
                String line = currentInput.nextLine();
                String[] strLines = new String[6];
                strLines = line.split(",");
                counter++;
                
                if (strLines[5].contains(wordsInName)){
                nameCounter++;
                String[] strLine = new String[6];
                strLine =line.split(",");
                totalPrice = Double.parseDouble(strLine[4]);
                if (strLine[1].equals("G")){
                    pkgType = "Gaming";
                }
                else if (strLine[1].equals("A")){
                    pkgType = "Anime";
                }
                if (strLine[1].equals("M")){
                    pkgType = "Movies";
                }
                if (strLine[3].equals("O")){
                    trmType = "One-off";
                }
                else if (strLine[3].equals("M")){
                    trmType = "monthly";
                }
                
                System.out.println("+---------------------------------------+");
                System.out.println("| Customer Name: " + strLine[5]);
                System.out.println("| Subscription Date: " + strLine[0]);
                System.out.println("| Package Type: " + pkgType);
                System.out.println("| Term: " + trmType + "\n");
                System.out.println("| Cost: " + totalPrice/100);
                System.out.println("+----------------------------------------+");
                
            }
            }
            
        }
            //This is to end the program
        else if(inputNumber == 5){
                System.out.println("Thanks for visiting\n"
                        + "Please shop wih us again");
                break;      
        }
      
        }
        }
        System.out.println("***Thanks for shopping with Geeky Gifts Inc***\n"
                + "\t\tPlease Visit Again");
     }
    //this is to get date format
    public static String getDate() { 
                 Calendar cal = Calendar.getInstance(); 
                 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
                 return sdf.format(cal.getTime()); 
            } 

    }

    

