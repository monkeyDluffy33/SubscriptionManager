
package subscriptionmanager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
//Bipul Bhatta
//2665649
public class Subscription {
    // Here We have classified everything we are going to ask customer in private string
    private String firstName;
    private String lastName;
    private String packageType;
    private int duration;
    private boolean term;
    private Double cost;
    private String termType;
// this is thw constructor of all the private classes
public Subscription (String firstName, String lastName, String packageType, int duration, boolean term, Double cost, String termType){
this.firstName = firstName;
this.lastName = lastName;
this.packageType = packageType;
this.duration = duration;
this.term = term;
this.termType = termType;
this.cost = cost;
}

   

   
// heere is the setter of all the classes
public void setFirstName(String firstName){
    this.firstName = firstName;
}
public void setLastName (String lastName){
    this.lastName = lastName;
}
public void setPackageType (String packageType){
    this.packageType = packageType;
}
public void setDuration (int duration) {
    this.duration = duration;
}   
public void setTerm (boolean term) {
    this.term = term;
}
public void setCost (Double cost) {
    this.cost = cost;
}
public void setTermType (String termtype) {
    this.termType = termtype;
}

    
// here is the getter of all classes
public String getFirstName() {
    return firstName;
}    
public String getLastName() {
    return lastName;
}
public String getPackageType() {
    return packageType;
}
public int getDuration() {
    return duration;
}
public boolean getTerm() {
    return term;
}
public Double getCost() {
    return cost;
}
public String getTermType() {
    return termType;
}
public static String getDate() 
 { 
 Calendar cal = Calendar.getInstance(); 
 SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy"); 
 return sdf.format(cal.getTime()); 
 } 
@Override
public String toString(){
    return    "+================================================+\n"
            + "|                            \n"
            + "| Customer: " + firstName +" "+ lastName + "\n"
            + "| Date: " + getDate() + "\n"
            + "| Package: " + packageType + "\tDuration: " + duration + "\n"
            + "| Terms: " + termType + "\n"
            + "| \t\t "+ termType +" Subscription: " +cost/100 + " \n"
            + "+================================================+";
    
            
}

}
